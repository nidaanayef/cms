نسخة 3.3.2
https://github.com/Kaakati/RTL_Bootstrap_3.3.2



============================================
RTL Bootstrap - Arabic بوتستراب عربي
================


بوتستراب عربي - نسخة 3.2.0 

Arabic Bootstrap - RTL

==================================

CSS قم بإستخدام ملف بوتستراب داخل مجلد 

<img src="http://bootstrap.steam-cloud.com/imgs/bootstrapARA.png">

<img src="http://getbootstrap.com/assets/img/devices.png">
